#!/usr/bin/env python3
"""
PRT Switch Manager
Manages switch configuration and monitoring
"""

import json
import subprocess
import time
import logging
import os
from datetime import datetime
from flask import Flask, jsonify, request, render_template_string

app = Flask(__name__)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class SwitchManager:
    def __init__(self):
        self.config_file = '/opt/switch/config/switch_config.json'
        self.config = self.load_config()
        self.interface_stats = {}
        
    def load_config(self):
        """Load switch configuration"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    return json.load(f)
            else:
                return self.create_default_config()
        except Exception as e:
            logger.error(f"Error loading config: {e}")
            return self.create_default_config()
    
    def create_default_config(self):
        """Create default switch configuration"""
        default_config = {
            "switch_name": "PRT_Switch_200",
            "management_ip": "192.168.1.200",
            "vlans": {
                "10": {"name": "control", "description": "PLC/HMI Control Network"},
                "20": {"name": "management", "description": "Database/SIEM Management"},
                "30": {"name": "security", "description": "Red/Blue Team Security"}
            },
            "port_config": {
                "eth0": {"mode": "trunk", "allowed_vlans": ["10", "20", "30"]},
                "eth1": {"mode": "access", "vlan": "10", "device": "PLC"},
                "eth2": {"mode": "access", "vlan": "10", "device": "HMI"},
                "eth3": {"mode": "access", "vlan": "20", "device": "Database"},
                "eth4": {"mode": "access", "vlan": "30", "device": "Red_Team"},
                "eth5": {"mode": "access", "vlan": "30", "device": "Blue_Team"}
            },
            "monitoring": {
                "enabled": True,
                "protocols": ["modbus", "ethernetip", "snmp"],
                "alert_threshold": 100
            }
        }
        
        # Save default config
        try:
            with open(self.config_file, 'w') as f:
                json.dump(default_config, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving default config: {e}")
        
        return default_config
    
    def get_interface_stats(self):
        """Get network interface statistics"""
        try:
            result = subprocess.run(['cat', '/proc/net/dev'], capture_output=True, text=True)
            lines = result.stdout.strip().split('\n')[2:]  # Skip header lines
            
            stats = {}
            for line in lines:
                if not line.strip():
                    continue
                    
                parts = line.split()
                interface = parts[0].rstrip(':')
                if ':' in interface:
                    continue
                    
                stats[interface] = {
                    'rx_bytes': int(parts[1]),
                    'rx_packets': int(parts[2]),
                    'tx_bytes': int(parts[9]),
                    'tx_packets': int(parts[10])
                }
            
            return stats
        except Exception as e:
            logger.error(f"Error getting interface stats: {e}")
            return {}
    
    def get_vlan_info(self):
        """Get VLAN information"""
        try:
            result = subprocess.run(['ip', 'link', 'show'], capture_output=True, text=True)
            lines = result.stdout.split('\n')
            
            vlans = {}
            for line in lines:
                if '@' in line and 'vlan' in line.lower():
                    parts = line.split()
                    vlan_interface = parts[1].rstrip(':')
                    if '.' in vlan_interface:
                        vlan_id = vlan_interface.split('.')[1]
                        vlans[vlan_id] = vlan_interface
            
            return vlans
        except Exception as e:
            logger.error(f"Error getting VLAN info: {e}")
            return {}
    
    def configure_vlan(self, vlan_id, interface='eth0'):
        """Configure a VLAN interface"""
        try:
            # Create VLAN interface
            subprocess.run(['ip', 'link', 'add', 'link', interface, 
                          f'{interface}.{vlan_id}', 'type', 'vlan', 'id', vlan_id], check=True)
            
            # Bring up the interface
            subprocess.run(['ip', 'link', 'set', f'{interface}.{vlan_id}', 'up'], check=True)
            
            logger.info(f"Created VLAN {vlan_id} on interface {interface}")
            return True
        except subprocess.CalledProcessError as e:
            logger.error(f"Error configuring VLAN {vlan_id}: {e}")
            return False
    
    def get_active_connections(self):
        """Get active network connections"""
        try:
            result = subprocess.run(['netstat', '-an'], capture_output=True, text=True)
            lines = result.stdout.split('\n')
            
            connections = []
            for line in lines:
                if 'ESTABLISHED' in line or 'LISTEN' in line:
                    parts = line.split()
                    if len(parts) >= 4:
                        connections.append({
                            'protocol': parts[0],
                            'local_address': parts[3],
                            'foreign_address': parts[4],
                            'state': parts[5] if len(parts) > 5 else ''
                        })
            
            return connections
        except Exception as e:
            logger.error(f"Error getting connections: {e}")
            return []
    
    def log_switch_event(self, event_type, details):
        """Log switch management events"""
        try:
            log_entry = {
                'timestamp': datetime.now().isoformat(),
                'event_type': event_type,
                'details': details
            }
            
            with open('/opt/switch/logs/switch_events.log', 'a') as f:
                f.write(json.dumps(log_entry) + '\n')
                
            logger.info(f"Switch event logged: {event_type}")
        except Exception as e:
            logger.error(f"Error logging switch event: {e}")

# Initialize switch manager
switch_manager = SwitchManager()

@app.route('/')
def index():
    """Switch management web interface"""
    html_template = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>PRT Switch Management</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; background: #1a1a1a; color: #00ff00; }
            .header { text-align: center; color: #00ffff; margin-bottom: 30px; }
            .panel { background: #2a2a2a; border: 2px solid #00ff00; padding: 20px; margin: 10px 0; border-radius: 10px; }
            .data-row { display: flex; justify-content: space-between; margin: 5px 0; }
            .refresh-btn { background: #00ff00; color: black; border: none; padding: 10px 20px; margin: 10px; cursor: pointer; }
        </style>
    </head>
    <body>
        <div class="header">PRT Network Switch Management</div>
        
        <div class="panel">
            <h3>Interface Statistics</h3>
            <div id="interface-stats">Loading...</div>
            <button class="refresh-btn" onclick="location.reload()">Refresh</button>
        </div>
        
        <div class="panel">
            <h3>VLAN Configuration</h3>
            <div id="vlan-info">Loading...</div>
        </div>
        
        <div class="panel">
            <h3>Active Connections</h3>
            <div id="connections">Loading...</div>
        </div>
        
        <script>
            function loadSwitchData() {
                fetch('/api/switch/status')
                    .then(response => response.json())
                    .then(data => {
                        // Display interface stats
                        let statsHtml = '';
                        for (let [iface, stats] of Object.entries(data.interface_stats)) {
                            statsHtml += `<div class="data-row">
                                <span>${iface}:</span>
                                <span>RX: ${stats.rx_packets} pkts, TX: ${stats.tx_packets} pkts</span>
                            </div>`;
                        }
                        document.getElementById('interface-stats').innerHTML = statsHtml;
                        
                        // Display VLAN info
                        let vlanHtml = '';
                        for (let [vlan, iface] of Object.entries(data.vlan_info)) {
                            vlanHtml += `<div class="data-row">
                                <span>VLAN ${vlan}:</span>
                                <span>${iface}</span>
                            </div>`;
                        }
                        document.getElementById('vlan-info').innerHTML = vlanHtml;
                        
                        // Display connections
                        let connHtml = '';
                        data.connections.slice(0, 10).forEach(conn => {
                            connHtml += `<div class="data-row">
                                <span>${conn.protocol}:</span>
                                <span>${conn.local_address} -> ${conn.foreign_address} (${conn.state})</span>
                            </div>`;
                        });
                        document.getElementById('connections').innerHTML = connHtml;
                    });
            }
            
            // Load data on page load
            loadSwitchData();
            
            // Refresh every 30 seconds
            setInterval(loadSwitchData, 30000);
        </script>
    </body>
    </html>
    """
    return html_template

@app.route('/api/switch/status')
def get_switch_status():
    """Get current switch status"""
    try:
        status = {
            'config': switch_manager.config,
            'interface_stats': switch_manager.get_interface_stats(),
            'vlan_info': switch_manager.get_vlan_info(),
            'connections': switch_manager.get_active_connections(),
            'timestamp': datetime.now().isoformat()
        }
        return jsonify(status)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/switch/configure', methods=['POST'])
def configure_switch():
    """Configure switch settings"""
    try:
        data = request.json
        switch_manager.config.update(data)
        
        # Save updated config
        with open(switch_manager.config_file, 'w') as f:
            json.dump(switch_manager.config, f, indent=2)
        
        switch_manager.log_switch_event('configuration_change', data)
        
        return jsonify({'success': True, 'message': 'Switch configuration updated'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=False)