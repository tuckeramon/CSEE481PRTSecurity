#!/usr/bin/env python3
"""
PRT Network Monitor
Monitors network traffic and logs suspicious activities
"""

import time
import subprocess
import json
import logging
import re
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class NetworkMonitor:
    def __init__(self):
        self.interface = 'eth0'
        self.log_file = '/opt/switch/logs/network_monitor.log'
        self.alert_threshold = 100  # packets per second
        self.monitoring = True
        
    def capture_traffic(self, duration=60):
        """Capture network traffic using tcpdump"""
        try:
            command = [
                'tcpdump',
                '-i', self.interface,
                '-c', '1000',
                '-n',
                '-t',
                'not port 22'
            ]
            
            result = subprocess.run(command, capture_output=True, text=True, timeout=duration)
            return result.stdout.split('\n')
        except subprocess.TimeoutExpired:
            logger.warning("Traffic capture timed out")
            return []
        except Exception as e:
            logger.error(f"Error capturing traffic: {e}")
            return []
    
    def analyze_traffic(self, packets):
        """Analyze captured packets for suspicious activity"""
        analysis = {
            'total_packets': len(packets),
            'modbus_traffic': [],
            'ethernetip_traffic': [],
            'suspicious_ips': set(),
            'high_frequency_connections': {},
            'protocol_distribution': {}
        }
        
        for packet in packets:
            if not packet.strip():
                continue
                
            # Look for Modbus traffic (port 502)
            if ':502' in packet:
                analysis['modbus_traffic'].append(packet)
                logger.info(f"Modbus traffic detected: {packet}")
            
            # Look for EtherNet/IP traffic (port 44818)
            if ':44818' in packet:
                analysis['ethernetip_traffic'].append(packet)
                logger.info(f"EtherNet/IP traffic detected: {packet}")
            
            # Extract IP addresses for frequency analysis
            ip_match = re.search(r'(\d+\.\d+\.\d+\.\d+\.\d+)', packet)
            if ip_match:
                ip = ip_match.group(1)
                if ip not in analysis['high_frequency_connections']:
                    analysis['high_frequency_connections'][ip] = 0
                analysis['high_frequency_connections'][ip] += 1
                
                # Flag high-frequency connections
                if analysis['high_frequency_connections'][ip] > 10:
                    analysis['suspicious_ips'].add(ip)
        
        return analysis
    
    def log_suspicious_activity(self, analysis):
        """Log suspicious network activities"""
        for ip in analysis['suspicious_ips']:
            activity_count = analysis['high_frequency_connections'][ip]
            logger.warning(f"Suspicious activity from IP {ip}: {activity_count} connections")
            
            # Write to alert log
            with open('/opt/switch/logs/security_alerts.log', 'a') as f:
                f.write(f"{datetime.now()} - High frequency connections from {ip}: {activity_count}\n")
        
        # Log ICS protocol usage
        if analysis['modbus_traffic']:
            logger.info(f"Detected {len(analysis['modbus_traffic'])} Modbus packets")
        
        if analysis['ethernetip_traffic']:
            logger.info(f"Detected {len(analysis['ethernetip_traffic'])} EtherNet/IP packets")
    
    def monitor_loop(self):
        """Main monitoring loop"""
        logger.info("Starting network monitoring...")
        
        while self.monitoring:
            try:
                # Capture traffic
                packets = self.capture_traffic(30)
                
                # Analyze traffic
                analysis = self.analyze_traffic(packets)
                
                # Log suspicious activities
                self.log_suspicious_activity(analysis)
                
                # Sleep before next capture
                time.sleep(10)
                
            except KeyboardInterrupt:
                logger.info("Stopping network monitoring...")
                break
            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")
                time.sleep(30)
    
    def start_monitoring(self):
        """Start the network monitoring"""
        self.monitoring = True
        self.monitor_loop()

if __name__ == "__main__":
    monitor = NetworkMonitor()
    monitor.start_monitoring()