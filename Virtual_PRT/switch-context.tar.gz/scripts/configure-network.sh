# Network configuration script for PRT switch
#!/bin/bash

echo "Configuring network interfaces for PRT switch..."

# Configure main interface
ip addr add 192.168.1.200/24 dev eth0
ip link set eth0 up

# Configure VLANs
ip link add link eth0 name eth0.10 type vlan id 10
ip link add link eth0 name eth0.20 type vlan id 20
ip link add link eth0 name eth0.30 type vlan id 30

ip addr add 192.168.1.201/24 dev eth0.10
ip addr add 192.168.1.202/24 dev eth0.20
ip addr add 192.168.1.203/24 dev eth0.30

ip link set eth0.10 up
ip link set eth0.20 up
ip link set eth0.30 up

echo "Network configuration completed"