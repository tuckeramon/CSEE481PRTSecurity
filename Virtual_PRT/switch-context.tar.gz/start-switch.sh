#!/bin/bash

# PRT Managed Switch Startup Script
# Initializes network switch with management services

echo "Starting PRT Managed Switch..."

# Set environment variables
export SWITCH_NAME=${SWITCH_NAME:-"schneider_switch_200"}
export SWITCH_IP=${SWITCH_IP:-"192.168.1.200"}
export SWITCH_VLAN_ENABLED=${SWITCH_VLAN_ENABLED:-"true"}

# Configure network interfaces
echo "Configuring network interfaces..."
ip addr add $SWITCH_IP/24 dev eth0
ip link set eth0 up

# Configure VLANs if enabled
if [ "$SWITCH_VLAN_ENABLED" = "true" ]; then
    echo "Configuring VLANs..."
    ip link add link eth0 name eth0.10 type vlan id 10  # Control network
    ip link add link eth0 name eth0.20 type vlan id 20  # Management network
    ip link add link eth0 name eth0.30 type vlan id 30  # Security network
    
    ip addr add 192.168.1.201/24 dev eth0.10
    ip addr add 192.168.1.202/24 dev eth0.20
    ip addr add 192.168.1.203/24 dev eth0.30
    
    ip link set eth0.10 up
    ip link set eth0.20 up
    ip link set eth0.30 up
fi

# Start Dropbear SSH server
echo "Starting SSH server..."
dropbear -F -p 22 &

# Start Lighttpd web server
echo "Starting web server..."
lighttpd -f /etc/lighttpd/lighttpd.conf &

# Start SNMP daemon
echo "Starting SNMP agent..."
snmpd -c /etc/snmp/snmpd.conf &

# Start network monitoring script
echo "Starting network monitoring..."
python3 /opt/switch/scripts/monitor_network.py &

# Start switch configuration daemon
echo "Starting switch management daemon..."
python3 /opt/switch/scripts/switch_manager.py &

# Keep container running
tail -f /dev/null